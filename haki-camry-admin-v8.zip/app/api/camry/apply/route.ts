import {NextResponse} from 'next/server';
import {z} from 'zod';
import {db} from '@/lib/db';
import {hashAdminPassword} from '@/lib/admin-auth';
const schema=z.object({name:z.string().min(2).max(80),email:z.string().email(),phone:z.string().max(30).optional(),password:z.string().min(8),note:z.string().max(500).optional()});
export async function POST(req:Request){try{const x=schema.parse(await req.json());const email=x.email.toLowerCase();const exists=await db.adminAccount.findUnique({where:{email}});if(exists)return NextResponse.json({error:'هذا البريد مستخدم بالفعل'},{status:400});const pending=await db.adminApplication.findFirst({where:{email,status:'PENDING'}});if(pending)return NextResponse.json({error:'لديك طلب قيد المراجعة بالفعل'},{status:400});await db.adminApplication.create({data:{name:x.name,email,phone:x.phone||null,passwordHash:hashAdminPassword(x.password),note:x.note||null}});return NextResponse.json({ok:true})}catch(e:any){return NextResponse.json({error:e?.message||'تعذر إرسال الطلب'},{status:400})}}
